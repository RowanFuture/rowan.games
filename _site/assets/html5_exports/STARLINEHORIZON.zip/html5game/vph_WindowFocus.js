function WindowFocus()
	{
  	window.focus();
	}