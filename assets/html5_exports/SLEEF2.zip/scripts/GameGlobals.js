﻿
// **********************************************************************************************************************
// 
// Copyright (c)2011, YoYo Games Ltd. All Rights reserved.
// 
// File:            global.js
// Created:         20/02/2011
// Author:          Mike
// Project:         HTML5
// Description:     variables in "GameGlobals" (rather than yyGlobals), are GML globals, not engine globals.
// 
// Date				Version		BY		Comment
// ----------------------------------------------------------------------------------------------------------------------
// 20/02/2011		V1.0        MJD     1st version
// 
// **********************************************************************************************************************


function    yyGameGlobals()
{
	this.__type = "global";
}
